# Generated from Ambiguo.g4 by ANTLR 4.13.2
from antlr4 import *
if "." in __name__:
    from .AmbiguoParser import AmbiguoParser
else:
    from AmbiguoParser import AmbiguoParser

# This class defines a complete listener for a parse tree produced by AmbiguoParser.
class AmbiguoListener(ParseTreeListener):

    # Enter a parse tree produced by AmbiguoParser#start.
    def enterStart(self, ctx:AmbiguoParser.StartContext):
        pass

    # Exit a parse tree produced by AmbiguoParser#start.
    def exitStart(self, ctx:AmbiguoParser.StartContext):
        pass


    # Enter a parse tree produced by AmbiguoParser#stmt.
    def enterStmt(self, ctx:AmbiguoParser.StmtContext):
        pass

    # Exit a parse tree produced by AmbiguoParser#stmt.
    def exitStmt(self, ctx:AmbiguoParser.StmtContext):
        pass


    # Enter a parse tree produced by AmbiguoParser#expr.
    def enterExpr(self, ctx:AmbiguoParser.ExprContext):
        pass

    # Exit a parse tree produced by AmbiguoParser#expr.
    def exitExpr(self, ctx:AmbiguoParser.ExprContext):
        pass



del AmbiguoParser