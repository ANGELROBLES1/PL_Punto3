grammar Ambiguo;

start : stmt+ EOF ;

stmt
    : 'if' expr 'then' stmt
    | 'if' expr 'then' stmt 'else' stmt
    | 'X'
    ;

expr : 'A' | 'B' ;

WS : [ \t\r\n]+ -> skip ;
