from antlr4 import *
from AmbiguoLexer import AmbiguoLexer
from AmbiguoParser import AmbiguoParser

def probar():
    with open("test.txt", "r") as f:
        contenido = f.read()

    input_stream = InputStream(contenido)
    lexer = AmbiguoLexer(input_stream)
    stream = CommonTokenStream(lexer)
    parser = AmbiguoParser(stream)

    tree = parser.start()
    print(tree.toStringTree(recog=parser))

if __name__ == "__main__":
    probar()
